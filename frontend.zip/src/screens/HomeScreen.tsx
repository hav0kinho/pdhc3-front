import React, { useEffect, useState } from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import ProdutosAgricolasCard from "../components/ProdutosAgricolasCard";
import QuantidadeProdutosCard from "../components/QuantidadeProdutosCard";
import ProdutoCarousel from "../components/ProdutoCarrousel";
import ResumoVendasCard from "../components/ResumoVendasCard";
import Produto from "../models/Produto";
import { getProdutos } from "../services/produtoService";
import { getVendas } from "../services/vendaService";
import Venda from "../models/Venda";
import { useResumoDoDia } from "../hooks/useResumoDoDia";
import { useDispatch } from "react-redux";
//REDUX
import { atualizarProdutos } from "../redux/slices/produtosSlice";
import { atualizarVendas } from "../redux/slices/vendasSlice";
import VendaCard from "../components/VendaCard";
import VendasCarrousel from "../components/VendaCarrousel";

const produtos = [
  {
    id: "1",
    nome: "Tomate Carioca",
    preco: 10.5,
    quantidade: 5,
    imagem: "https://via.placeholder.com/150",
  },
  {
    id: "2",
    nome: "Cenoura Orgânica",
    preco: 7.3,
    quantidade: 10,
    imagem: "https://via.placeholder.com/150",
  },
  {
    id: "3",
    nome: "Batata Doce",
    preco: 8.9,
    quantidade: 15,
    imagem: "https://via.placeholder.com/150",
  },
  {
    id: "4",
    nome: "Batata Doce",
    preco: 8.9,
    quantidade: 15,
    imagem: "https://via.placeholder.com/150",
  },
  {
    id: "5",
    nome: "Batata Doce",
    preco: 8.9,
    quantidade: 15,
    imagem: "https://via.placeholder.com/150",
  },
  {
    id: "6",
    nome: "Batata Doce",
    preco: 8.9,
    quantidade: 15,
    imagem: "https://via.placeholder.com/150",
  },
  {
    id: "7",
    nome: "Batata Doce",
    preco: 8.9,
    quantidade: 15,
    imagem: "https://via.placeholder.com/150",
  },
];

const HomeScreen = ({ navigation }: { navigation: any }) => {
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [vendas, setVendas] = useState<Venda[]>([]);
  const { vendasDoDia, quantidadeVendas, valorTotal } = useResumoDoDia();
  const [isLoading, setIsLoading] = useState(true);

  const dispatch = useDispatch();

  const fetchProdutos = async () => {
    setIsLoading(true);
    try {
      const data = await getProdutos();
      // console.log(data);
      setProdutos(data);
      dispatch(atualizarProdutos(data));
    } catch (e) {
      console.error("Erro ao buscar produtos", e);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchVendas = async () => {
    setIsLoading(true);
    try {
      const data = await getVendas();
      console.log(data);
      setVendas(data);
      dispatch(atualizarVendas(data));
    } catch (e) {
      console.error("Erro ao buscar vendas", e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProdutos();
    fetchVendas();
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.produtoCardContainer}>
        <ProdutosAgricolasCard />
        <QuantidadeProdutosCard quantidadeProdutos={produtos.length} />
      </View>
      <View style={styles.produtosCarouselContainer}>
        <ProdutoCarousel listaProdutos={produtos} />
      </View>
      <View style={styles.resumoVendasContainer}>
        <ResumoVendasCard
          quantidadeVendas={quantidadeVendas}
          valorTotal={valorTotal}
        />
      </View>
      <View>
        <VendasCarrousel listaVendas={vendasDoDia} />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: "#627053",
  },
  produtoCardContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  produtosCarouselContainer: {
    marginTop: 10,
  },
  resumoVendasContainer: {
    marginTop: 10,
  },
});

export default HomeScreen;

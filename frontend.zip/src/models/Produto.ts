type Produto = {
  id: string;
  nome: string;
  precoUnidade: number;
  quantidade: number;
  imagemUrl: string;
};

export default Produto;

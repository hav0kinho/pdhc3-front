import Venda from "../models/Venda";
import { apiFetch, apiRoutes } from "./api";

export const getVendas = async (): Promise<Venda[]> => {
  try {
    const data = await apiFetch(apiRoutes.venda, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const vendas: Venda[] = [];
    data.map((venda: Venda) => {
      const produtosVendidos = venda.produtosVendidos.map((produto) => ({
        id: produto.id,
        quantidadeVendida: produto.quantidadeVendida,
        valorPago: Number(produto.valorPago),
        vendaId: produto.vendaId,
        produtoId: produto.produtoId,
      }));

      const novaVenda: Venda = {
        id: venda.id,
        latitude: venda.latitude,
        longitude: venda.longitude,
        dataVenda: new Date(venda.dataVenda).toString(),
        valorTotal: Number(venda.valorTotal),
        produtosVendidos,
      };

      vendas.push(novaVenda);
    });
    return vendas;
  } catch (error) {
    console.error("Erro ao buscar os produtos do back: " + error);
    return [];
  }
};

const baseUrl = "http://10.0.2.2:3000";
export const apiRoutes = {
  produto: `${baseUrl}/api/produtos`,
  venda: `${baseUrl}/api/vendas`,
};

export const apiFetch = async (url: string, options: RequestInit) => {
  try {
    const response = await fetch(url, options);

    if (!response.ok) {
      throw new Error(`Erro na requisição: ${response.statusText}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error(`Erro ao acessar ${url}:`, error);
    throw error; // Rejeitar a promessa para lidar no chamador
  }
};

const GLOBALSTYLE = {
  homeBackground: "#627053",
  homeHeader: "#627053",
};

export default GLOBALSTYLE;

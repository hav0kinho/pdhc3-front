import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import Produto from "../../models/Produto";

interface ProdutosState {
  lista: Produto[];
}

const initialState: ProdutosState = {
  lista: [],
};

const produtosSlice = createSlice({
  name: "produtos",
  initialState,
  reducers: {
    adicionarProduto(state, action: PayloadAction<Produto>) {
      state.lista.push(action.payload);
    },
    removerProduto(state, action: PayloadAction<string>) {
      state.lista = state.lista.filter(
        (produto) => produto.id !== action.payload
      );
    },
    atualizarProdutos(state, action: PayloadAction<Produto[]>) {
      state.lista = action.payload;
    },
  },
});

export const { adicionarProduto, removerProduto, atualizarProdutos } =
  produtosSlice.actions;
export default produtosSlice.reducer;
